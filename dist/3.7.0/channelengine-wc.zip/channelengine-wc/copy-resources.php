<?php

include __DIR__ . '/Lib/class-resource-copier.php';
\ChannelEngine\Lib\Resource_Copier::copy();