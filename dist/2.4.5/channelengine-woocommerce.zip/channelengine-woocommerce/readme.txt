=== WooCommerce ChannelEngine ===
Contributors: channelengine
Donate link: 
Tags: woocommerce, channelengine, marketplaces
Requires at least: 4.4
Tested up to: 5.3.2
Stable tag: master
License: MIT
License URI: https://opensource.org/licenses/MIT

With ChannelEngine you will get the means to instantly connect to your favorite marketplaces, comparison engines, affiliate programs and others.

== Description ==

Millions of people visit websites like Bol.com, Amazon, Beslist and Kieskeurig looking for particular products. To reach these people you can sell your products on these marketplaces.
With ChannelEngine you will get the means to instantly connect to your favorite marketplaces, comparison engines, affiliate programs and other partners. One single connection between ChannelEngine and your e-commerce platform or ERP system allows you to optimize your product feeds and receive orders from your external sales channels.
This plugin will make this connection even easier. When the plugin is installed you only have to fill out your ChannelEngine details and you are good to go.

== Installation ==

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Fill in your API keys in the ChannelEngine settings