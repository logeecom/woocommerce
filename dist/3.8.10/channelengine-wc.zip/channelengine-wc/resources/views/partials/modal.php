<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<div class="ce-modal">
	<div class="ce-modal-dialog">
		<div id="ce-modal-content" class="ce-modal-content">
			<header>
				<h3>This is modal header</h3>
				<span class="ce-close-modal ce-close-button">✕</span>
			</header>
			<main>
			</main>
			<footer>
				<button id="ce-modal-btn" class="ce-button ce-button__primary ce-close-modal">Close</button>
			</footer>
		</div>
	</div>
</div>
