<?php

namespace ChannelEngine\Components\Exceptions;

use ChannelEngine\Infrastructure\Exceptions\BaseException;

/**
 * Class Cancellation_Rejected_Exception
 *
 * @package ChannelEngine\Components\Exceptions
 */
class Cancellation_Rejected_Exception extends BaseException {

}
