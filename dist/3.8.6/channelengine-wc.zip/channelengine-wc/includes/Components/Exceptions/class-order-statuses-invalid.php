<?php

namespace ChannelEngine\Components\Exceptions;

use ChannelEngine\Infrastructure\Exceptions\BaseException;

/**
 * Class Order_Statuses_Invalid
 *
 * @package ChannelEngine\Components\Exceptions
 */
class Order_Statuses_Invalid extends BaseException {

}
