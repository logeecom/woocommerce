<?php

namespace ChannelEngine\Components\Exceptions;

use ChannelEngine\Infrastructure\Exceptions\BaseException;

/**
 * Class Stock_Sync_Flag_Invalid
 *
 * @package ChannelEngine\Components\Exceptions
 */
class Stock_Sync_Flag_Invalid extends BaseException {

}
