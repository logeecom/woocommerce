<?php

namespace ChannelEngine\Repositories;

/**
 * Class Buffer_Repository
 *
 * @package ChannelEngine\Repositories
 */
class Buffer_Repository extends Base_Repository {
	const THIS_CLASS_NAME = __CLASS__;
	const TABLE_NAME = 'channel_engine_events';
}