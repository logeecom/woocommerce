<?php

namespace ChannelEngine\Repositories;

class Log_Repository extends Base_Repository {
	const THIS_CLASS_NAME = __CLASS__;
	const TABLE_NAME      = 'channel_engine_logs';
}
