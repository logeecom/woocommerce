<?php

namespace ChannelEngine\Components\Exceptions;

use ChannelEngine\Infrastructure\Exceptions\BaseException;

/**
 * Class Shipment_Rejected_Exception
 *
 * @package ChannelEngine\Components\Exceptions
 */
class Shipment_Rejected_Exception extends BaseException {

}
