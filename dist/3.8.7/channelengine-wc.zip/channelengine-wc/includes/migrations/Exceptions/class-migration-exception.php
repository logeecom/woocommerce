<?php


namespace ChannelEngine\Migrations\Exceptions;

use Exception;

/**
 * Class Migration_Exception
 *
 * @package ChannelEngine\Migrations\Exceptions
 */
class Migration_Exception extends Exception {


}
