<?php

namespace ChannelEngine\Components\Services;


use ChannelEngine\BusinessLogic\SupportConsole\SupportService;
use ChannelEngine\Repositories\Plugin_Options_Repository;
use ChannelEngine\Utility\Database;

/**
 * Class Support_Service
 *
 * @package ChannelEngine\Components\Services
 */
class Support_Service extends SupportService {
	/**
	 * @inheritDoc
	 */
	protected function hardReset() {
		$database = new Database( new Plugin_Options_Repository() );
		$database->remove_data();
	}
}